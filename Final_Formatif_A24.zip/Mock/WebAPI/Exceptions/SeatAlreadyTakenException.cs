﻿using System;
namespace WebAPI.Exceptions
{
	public class SeatAlreadyTakenException : Exception
    {
	}
}

