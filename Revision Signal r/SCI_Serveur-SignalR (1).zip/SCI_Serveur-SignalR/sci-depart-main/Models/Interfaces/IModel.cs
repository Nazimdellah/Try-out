﻿using System;
namespace Models.Interfaces
{
	public interface IModel
	{
		public int Id { get; set; }
	}
}

