Petite application de Chat qui utilise SignalR
